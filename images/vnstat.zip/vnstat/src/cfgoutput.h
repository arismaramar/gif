#ifndef CFGOUTPUT_H
#define CFGOUTPUT_H

void printcfgfile(void);

#endif
