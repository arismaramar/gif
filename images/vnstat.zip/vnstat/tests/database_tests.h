#ifndef DATABASE_TESTS_H
#define DATABASE_TESTS_H

void add_database_tests(Suite *s);

#endif
